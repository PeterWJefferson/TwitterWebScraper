
package business;

import java.util.ArrayList;
import java.io.Serializable;

public class Teamlist2 {
    
    private ArrayList<Team> teams;
    
    public Teamlist2(){
        teams = new ArrayList<Team>();
    }
    public ArrayList<Team> getTeams(){
        return teams;
    }
    public void addTeam(Team team){
        teams.add(team);
    }
    
    
}
