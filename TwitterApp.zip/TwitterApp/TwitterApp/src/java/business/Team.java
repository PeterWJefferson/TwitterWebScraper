package business;

import java.io.Serializable;

public class Team implements Serializable {

    private String team;
    private int count;

    public Team() {
        team = "";
        count = 0;
    }

    public Team(String team, int count) {
        this.team = team;
        this.count = count;
    }
    
    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }
    
    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    /*private String illinois;
    private String iowa;
    private String minnesota;
    private String nebraska;
    private String northwestern;
    private String purdue;
    private String wisconsin;
    private String alabama;
    private String clemson;
    private String notredame;
    private String georgia;
    private String oklahoma;
    private String ohiostate;
    private String michigan;
    private String ucf;
    private String florida;
    private String lsu;
    private String washington;
    private String pennstate;
    private String washingtonstate;
    private String texas;
    private String kentucky;
    private String westvirginia;
    private String utah;
    private String mississippistate;
    private String texasam;
    private String syracuse;
    private String boisestate;
    private String iowastate;
    private String missouri;
    private String fresnostate;*/
}
