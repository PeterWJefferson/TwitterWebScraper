
package business;

import java.util.ArrayList;
import java.io.Serializable;

public class Teamlist1 {
    
    private ArrayList<Team> teams;
    
    public Teamlist1(){
        teams = new ArrayList<Team>();
    }
    public ArrayList<Team> getTeams(){
        return teams;
    }
    public void addTeam(Team team){
        teams.add(team);
    }
    public int getCount(){
        return teams.size();
    }
    public void removeTeams() {
        for(int i=0; i<teams.size();i++){
                teams.remove(i);
                return;
            }
    }
}
    
    
    
 
