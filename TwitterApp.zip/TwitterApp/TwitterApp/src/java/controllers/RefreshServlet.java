package controllers;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.*;

import java.util.List;

import business.*;
import java.util.logging.Level;

public class RefreshServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        ServletContext sc = getServletContext();

        String action = request.getParameter("action");
        if (action == null) {
            action = "refresh";
        }
        String message;
        String url = "/index.jsp";
        if (action.equals("refresh")) {
            String teams = request.getParameter("teams");
            if (teams.equals("Top 25")) {

                try {
                    HttpSession session = request.getSession();
                    Teamlist1 teamlist = (Teamlist1) session.getAttribute("teamlist");
                    if (teamlist == null) {
                        teamlist = new Teamlist1();
                    }
                    /*if (teamlist != null){
                        teamlist = new Teamlist1();
                    }*/

                    ConfigurationBuilder cf = new ConfigurationBuilder();

                    cf.setDebugEnabled(true)
                            .setOAuthConsumerKey("10PdSAtKh4o8aQ6YEFWTrZwfi")
                            .setOAuthConsumerSecret("lw5QUX0RnA81oPjyW7QY5EtRyu5LH3bGGP51g4snSjddl3tUMO")
                            .setOAuthAccessToken("1063151798712721409-mJ2qwIXo8rRR4XRWFVLHvvwl0Sw5Yl")
                            .setOAuthAccessTokenSecret("m5I1wP4vRUbLgvsMFadUb585BJyu3ZX5pd9fC7FdmjHlQ");

                    TwitterFactory tf = new TwitterFactory(cf.build());
                    twitter4j.Twitter twitter = tf.getInstance();
                    /*twitter4j.Twitter twitter =  TwitterFactory.getSingleton();
                    Query query = new Query("ipl7");
                    QueryResult result = twitter.search(query);
                    for(Status st: status){
                    System.out.println(st.getUser().getName()+"-----"+st.getText());
                    }*/

                    //Query query = new Query("@ESPNCFB Alabama");
                    //QueryResult result = twitter.search(query);
                    List<Status> status = twitter.getHomeTimeline(new Paging(1, 200));
                    /*for (Status st : status) {
                    System.out.println(st.getUser().getName() + "-----" + st.getText());
                    }*/
                    List<Status> status1 = twitter.getHomeTimeline(new Paging(2, 200));

                    int alabama = 0;
                    int clemson = 0;
                    int notredame = 0;
                    int georgia = 0;
                    int oklahoma = 0;
                    int ohiostate = 0;
                    int michigan = 0;
                    int ucf = 0;
                    int florida = 0;
                    int lsu = 0;
                    int washington = 0;
                    int pennstate = 0;
                    int washingtonstate = 0;
                    int texas = 0;
                    int kentucky = 0;
                    int westvirginia = 0;
                    int utah = 0;
                    int mississippistate = 0;
                    int texasam = 0;
                    int syracuse = 0;
                    int northwestern = 0;
                    int boisestate = 0;
                    int iowastate = 0;
                    int missouri = 0;
                    int fresnostate = 0;

                    for (Status st : status) {
                        if (st.getText().contains("Alabama")) {
                            alabama++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Alabama")) {
                            alabama++;
                        }
                    }
                    //CRIMSON TIDE
                    for (Status st : status) {
                        if (st.getText().contains("Tide")) {
                            alabama++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Tide")) {
                            alabama++;
                        }
                    }
                    //CLEMSON
                    for (Status st : status) {
                        if (st.getText().contains("Clemson")) {
                            clemson++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Clemson")) {
                            clemson++;
                        }
                    }

                    //NOTRE DAME
                    for (Status st : status) {
                        if (st.getText().contains("Notre Dame")) {
                            notredame++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Notre Dame")) {
                            notredame++;
                        }
                    }

                    //GEORGIA
                    for (Status st : status) {
                        if (st.getText().contains("Georgia")) {
                            georgia++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Georgia")) {
                            georgia++;
                        }
                    }
                    //MINUS GEORGIA TECH
                    for (Status st : status) {
                        if (st.getText().contains("Georgia Tech")) {
                            georgia--;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Georgia Tech")) {
                            georgia--;
                        }
                    }

                    //OKLAHOMA
                    for (Status st : status) {
                        if (st.getText().contains("Oklahoma")) {
                            oklahoma++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Oklahoma")) {
                            oklahoma++;
                        }
                    }
                    //SOONERS
                    for (Status st : status) {
                        if (st.getText().contains("Sooners")) {
                            oklahoma++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Sooners")) {
                            oklahoma++;
                        }
                    }
                    //MINUS OKLAHOMA STATE
                    for (Status st : status) {
                        if (st.getText().contains("Oklahoma State")) {
                            oklahoma--;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Oklahoma State")) {
                            oklahoma--;
                        }
                    }
                    //OHIO STATE
                    for (Status st : status) {
                        if (st.getText().contains("Ohio State")) {
                            ohiostate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Ohio State")) {
                            ohiostate++;
                        }
                    }
                    //BUCKEYES
                    for (Status st : status) {
                        if (st.getText().contains("Buckeyes")) {
                            ohiostate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Buckeyes")) {
                            ohiostate++;
                        }
                    }

                    //MICHIGAN
                    for (Status st : status) {
                        if (st.getText().contains("Michigan")) {
                            michigan++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Michigan")) {
                            michigan++;
                        }
                    }
                    //WOLVERINES
                    for (Status st : status) {
                        if (st.getText().contains("Wolverines")) {
                            michigan++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Wolverines")) {
                            michigan++;
                        }
                    }
                    //MINUS MICHIGAN STATE
                    for (Status st : status) {
                        if (st.getText().contains("Michigan State")) {
                            michigan--;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Michigan State")) {
                            michigan--;
                        }
                    }

                    //UCF
                    for (Status st : status) {
                        if (st.getText().contains("UCF")) {
                            ucf++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("UCF")) {
                            ucf++;
                        }
                    }
                    //CENTRAL FLORIDA
                    for (Status st : status) {
                        if (st.getText().contains("Central Florida")) {
                            ucf++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Central Florida")) {
                            ucf++;
                        }
                    }

                    //Florida
                    for (Status st : status) {
                        if (st.getText().contains("Florida")) {
                            florida++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Florida")) {
                            florida++;
                        }
                    }
                    //GATORS
                    for (Status st : status) {
                        if (st.getText().contains("Gators")) {
                            florida++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Gators")) {
                            florida++;
                        }
                    }
                    //MINUS UCF
                    for (Status st : status) {
                        if (st.getText().contains("Central Florida")) {
                            florida--;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Central Florida")) {
                            florida--;
                        }
                    }
                    //MINUS FLORIDA STATE
                    for (Status st : status) {
                        if (st.getText().contains("Florida State")) {
                            florida--;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Florida State")) {
                            florida--;
                        }
                    }

                    //LSU
                    for (Status st : status) {
                        if (st.getText().contains("LSU")) {
                            lsu++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("LSU")) {
                            lsu++;
                        }
                    }
                    //WASHINGTON
                    for (Status st : status) {
                        if (st.getText().contains("Washington")) {
                            washington++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Washington")) {
                            washington++;
                        }
                    }

                    //MINUS WASHINGTON STATE
                    for (Status st : status) {
                        if (st.getText().contains("Washington State")) {
                            washington--;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Washington State")) {
                            washington--;
                        }
                    }

                    //PENN STATE
                    for (Status st : status) {
                        if (st.getText().contains("Penn State")) {
                            pennstate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Penn State")) {
                            pennstate++;
                        }
                    }

                    //WASHINGTION STATE
                    for (Status st : status) {
                        if (st.getText().contains("Washington State")) {
                            washingtonstate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Washington State")) {
                            washingtonstate++;
                        }
                    }

                    //TEXAS
                    for (Status st : status) {
                        if (st.getText().contains("Texas")) {
                            texas++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Texas")) {
                            texas++;
                        }
                    }
                    //LONGHORNS
                    for (Status st : status) {
                        if (st.getText().contains("Longhorns")) {
                            texas++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Longhorns")) {
                            texas++;
                        }
                    }
                    //MINUS TEXAS TECH
                    for (Status st : status) {
                        if (st.getText().contains("Texas Tech")) {
                            texas--;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Texas Tech")) {
                            texas--;
                        }
                    }
                    //MINUS A&M
                    for (Status st : status) {
                        if (st.getText().contains("Texas A&M")) {
                            texas--;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Texas A&M")) {
                            texas--;
                        }
                    }
                    //KENTUCKY
                    for (Status st : status) {
                        if (st.getText().contains("Kentucky")) {
                            kentucky++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Kentucky")) {
                            kentucky++;
                        }
                    }
                    //WEST VIRGINIA
                    for (Status st : status) {
                        if (st.getText().contains("West Virginia")) {
                            westvirginia++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("West Virginia")) {
                            westvirginia++;
                        }
                    }
                    //MOUNTAINEERS
                    for (Status st : status) {
                        if (st.getText().contains("Mountaineers")) {
                            westvirginia++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Mountaineers")) {
                            westvirginia++;
                        }
                    }
                    //UTAH
                    for (Status st : status) {
                        if (st.getText().contains("Utah")) {
                            utah++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Utah")) {
                            utah++;
                        }
                    }
                    //MINUS UTAH STATE
                    for (Status st : status) {
                        if (st.getText().contains("Utah State")) {
                            utah--;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Utah State")) {
                            utah--;
                        }
                    }
                    //MISSISSIPPI STATE
                    for (Status st : status) {
                        if (st.getText().contains("Mississippi State")) {
                            mississippistate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Mississippi State")) {
                            mississippistate++;
                        }
                    }
                    //MISS STATE
                    for (Status st : status) {
                        if (st.getText().contains("Miss State")) {
                            mississippistate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Miss State")) {
                            mississippistate++;
                        }
                    }
                    //TEXAS A&M
                    for (Status st : status) {
                        if (st.getText().contains("A&M")) {
                            texasam++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("A&M")) {
                            texasam++;
                        }
                    }
                    //SYRACUSE
                    for (Status st : status) {
                        if (st.getText().contains("Syracuse")) {
                            syracuse++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Syracuse")) {
                            syracuse++;
                        }
                    }
                    //CUSE
                    for (Status st : status) {
                        if (st.getText().contains("Cuse")) {
                            syracuse++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Cuse")) {
                            syracuse++;
                        }
                    }
                    //NORTHWESTERN
                    for (Status st : status) {
                        if (st.getText().contains("Northwestern")) {
                            northwestern++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Northwestern")) {
                            northwestern++;
                        }
                    }
                    //BOISE STATE
                    for (Status st : status) {
                        if (st.getText().contains("Boise")) {
                            boisestate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Boise")) {
                            boisestate++;
                        }
                    }
                    //IOWA STATE
                    for (Status st : status) {
                        if (st.getText().contains("Iowa State")) {
                            iowastate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Iowa State")) {
                            iowastate++;
                        }
                    }
                    //CYCLONES
                    for (Status st : status) {
                        if (st.getText().contains("Cyclones")) {
                            iowastate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Cyclones")) {
                            iowastate++;
                        }
                    }
                    //MISSOURI
                    for (Status st : status) {
                        if (st.getText().contains("Missouri")) {
                            missouri++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Missouri")) {
                            missouri++;
                        }
                    }
                    //MIZZOU
                    for (Status st : status) {
                        if (st.getText().contains("Mizzou")) {
                            missouri++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Mizzou")) {
                            missouri++;
                        }
                    }
                    //FRESNO STATE
                    for (Status st : status) {
                        if (st.getText().contains("Fresno State")) {
                            fresnostate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Fresno State")) {
                            fresnostate++;
                        }
                    }
                    
                    Team team1 = new Team("Alabama", alabama);
                    Team team2 = new Team("Clemson", clemson);
                    Team team3 = new Team("Notre Dame", notredame);
                    Team team4 = new Team("Georgia", georgia);
                    Team team5 = new Team("Oklahoma", oklahoma);
                    Team team6 = new Team("Ohio State", ohiostate);
                    Team team7 = new Team("Michigan", michigan);
                    Team team8 = new Team("UCF", ucf);
                    Team team9 = new Team("Florida", florida);
                    Team team10 = new Team("LSU", lsu);
                    Team team11 = new Team("Washington", washington);
                    Team team12 = new Team("Penn State", pennstate);
                    Team team13 = new Team("Washington State", washingtonstate);
                    Team team14 = new Team("Texas", texas);
                    Team team15 = new Team("Kentucky", kentucky);
                    Team team16 = new Team("West Virginia", westvirginia);
                    Team team17 = new Team("Utah", utah);
                    Team team18 = new Team("Mississippi State", mississippistate);
                    Team team19 = new Team("Texas A&M", texasam);
                    Team team20 = new Team("Syracuse", syracuse);
                    Team team21 = new Team("Northwestern", northwestern);
                    Team team22 = new Team("Boise State", boisestate);
                    Team team23 = new Team("Iowa State", iowastate);
                    Team team24 = new Team("Missouri", missouri);
                    Team team25 = new Team("Fresno State", fresnostate);
                    
                    //teamlist.removeTeams();
                    
                    teamlist.addTeam(team1);
                    teamlist.addTeam(team2);
                    teamlist.addTeam(team3);
                    teamlist.addTeam(team4);
                    teamlist.addTeam(team5);
                    teamlist.addTeam(team6);
                    teamlist.addTeam(team7);
                    teamlist.addTeam(team8);
                    teamlist.addTeam(team9);
                    teamlist.addTeam(team10);
                    teamlist.addTeam(team11);
                    teamlist.addTeam(team12);
                    teamlist.addTeam(team13);
                    teamlist.addTeam(team14);
                    teamlist.addTeam(team15);
                    teamlist.addTeam(team16);
                    teamlist.addTeam(team17);
                    teamlist.addTeam(team18);
                    teamlist.addTeam(team19);
                    teamlist.addTeam(team20);
                    teamlist.addTeam(team21);
                    teamlist.addTeam(team22);
                    teamlist.addTeam(team23);
                    teamlist.addTeam(team24);
                    teamlist.addTeam(team25);

                    //teamlist.getTeams();
                    session.setAttribute("teamlist", teamlist);
                    url = "/index.jsp";
                    //url="/test.jsp";
                } catch (TwitterException ex) {
                    java.util.logging.Logger.getLogger(RefreshServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                try {
                    HttpSession session = request.getSession();
                    Teamlist1 teamlist = (Teamlist1) session.getAttribute("teamlist");
                    if (teamlist == null) {
                        teamlist = new Teamlist1();
                    }

                    ConfigurationBuilder cf = new ConfigurationBuilder();

                    cf.setDebugEnabled(true)
                            .setOAuthConsumerKey("10PdSAtKh4o8aQ6YEFWTrZwfi")
                            .setOAuthConsumerSecret("lw5QUX0RnA81oPjyW7QY5EtRyu5LH3bGGP51g4snSjddl3tUMO")
                            .setOAuthAccessToken("1063151798712721409-mJ2qwIXo8rRR4XRWFVLHvvwl0Sw5Yl")
                            .setOAuthAccessTokenSecret("m5I1wP4vRUbLgvsMFadUb585BJyu3ZX5pd9fC7FdmjHlQ");

                    TwitterFactory tf = new TwitterFactory(cf.build());
                    twitter4j.Twitter twitter = tf.getInstance();
                    /*twitter4j.Twitter twitter =  TwitterFactory.getSingleton();
                    Query query = new Query("ipl7");
                    QueryResult result = twitter.search(query);
                    for(Status st: status){
                    System.out.println(st.getUser().getName()+"-----"+st.getText());
                    }*/

                    //Query query = new Query("@ESPNCFB Alabama");
                    //QueryResult result = twitter.search(query);
                    List<Status> status = twitter.getHomeTimeline(new Paging(1, 200));
                    /*for (Status st : status) {
                    System.out.println(st.getUser().getName() + "-----" + st.getText());
                    }*/
                    List<Status> status1 = twitter.getHomeTimeline(new Paging(2, 200));

                    int indiana = 0;
                    int maryland = 0;
                    int michiganstate = 0;
                    int rutgers = 0;
                    int ohiostate = 0;
                    int michigan = 0;
                    int pennstate = 0;
                    int illinois = 0;
                    int iowa = 0;
                    int minnesota = 0;
                    int nebraska = 0;
                    int northwestern = 0;
                    int purdue = 0;
                    int wisconsin = 0;

//loops
//INDIANA UNIVERSITY
                    for (Status st : status) {
                        if (st.getText().contains("Indiana")) {
                            indiana++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Indiana")) {
                            indiana++;
                        }
                    }

//MARYLAND
                    for (Status st : status) {
                        if (st.getText().contains("Maryland")) {
                            maryland++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Maryland")) {
                            maryland++;
                        }
                    }

//MICHIGAN STATE MINUS MICHIGAN
                    for (Status st : status) {
                        if (st.getText().contains("Michigan State")) {
                            michiganstate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Michigan State")) {
                            michiganstate++;
                        }
                    }

//RUTGERS
                    for (Status st : status) {
                        if (st.getText().contains("Rutgers")) {
                            rutgers++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Rutgers")) {
                            rutgers++;
                        }
                    }

//OHIO STATE
                    for (Status st : status) {
                        if (st.getText().contains("Ohio State")) {
                            ohiostate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Ohio State")) {
                            ohiostate++;
                        }
                    }
//BUCKEYES
                    for (Status st : status) {
                        if (st.getText().contains("Buckeyes")) {
                            ohiostate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Buckeyes")) {
                            ohiostate++;
                        }
                    }

//MICHIGAN
                    for (Status st : status) {
                        if (st.getText().contains("Michigan")) {
                            michigan++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Michigan")) {
                            michigan++;
                        }
                    }
//WOLVERINES
                    for (Status st : status) {
                        if (st.getText().contains("Wolverines")) {
                            michigan++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Wolverines")) {
                            michigan++;
                        }
                    }
//MINUS MICHIGAN STATE
                    for (Status st : status) {
                        if (st.getText().contains("Michigan State")) {
                            michigan--;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Michigan State")) {
                            michigan--;
                        }
                    }

//PENN STATE
                    for (Status st : status) {
                        if (st.getText().contains("Penn State")) {
                            pennstate++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Penn State")) {
                            pennstate++;
                        }
                    }

                    for (Status st : status) {
                        if (st.getText().contains("Illinois")) {
                            illinois++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Illinois")) {
                            illinois++;
                        }
                    }
                    //ILLINI
                    for (Status st : status) {
                        if (st.getText().contains("Illini")) {
                            illinois++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Illini")) {
                            illinois++;
                        }
                    }
                    //IOWA  + HAWKEYES - "IOWA STATE"
                    for (Status st : status) {
                        if (st.getText().contains("Iowa")) {
                            iowa++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Iowa")) {
                            iowa++;
                        }
                    }
                    //HAWKEYES
                    for (Status st : status) {
                        if (st.getText().contains("Hawkeyes")) {
                            iowa++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Hawkeyes")) {
                            iowa++;
                        }
                    }
                    //IOWA STATE
                    for (Status st : status) {
                        if (st.getText().contains("Iowa State")) {
                            iowa--;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Iowa State")) {
                            iowa--;
                        }
                    }

                    //MINNESOTA
                    for (Status st : status) {
                        if (st.getText().contains("Minnesota")) {
                            minnesota++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Minnesota")) {
                            minnesota++;
                        }
                    }
                    //GOLDEN GOPHERS
                    for (Status st : status) {
                        if (st.getText().contains("Golden Gopher")) {
                            minnesota++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Golden Gopher")) {
                            minnesota++;
                        }
                    }
                    //NEBRASKA + CORNHUSKERS
                    for (Status st : status) {
                        if (st.getText().contains("Nebraska")) {
                            nebraska++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Nebraska")) {
                            nebraska++;
                        }
                    }
                    //CORNHUSKERS
                    for (Status st : status) {
                        if (st.getText().contains("Cornhuskers")) {
                            nebraska++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Cornhuskers")) {
                            nebraska++;
                        }
                    }

                    //NORTHWESTERN
                    for (Status st : status) {
                        if (st.getText().contains("Northwestern")) {
                            northwestern++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Northwestern")) {
                            northwestern++;
                        }
                    }

                    //PURDUE + BOILERMAKERS
                    for (Status st : status) {
                        if (st.getText().contains("Purdue")) {
                            purdue++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Purdue")) {
                            purdue++;
                        }
                    }

                    //BOILERMAKERS
                    for (Status st : status) {
                        if (st.getText().contains("Boilermaker")) {
                            purdue++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Boilermaker")) {
                            purdue++;
                        }
                    }

                    //WISCONSIN + BADGERS
                    for (Status st : status) {
                        if (st.getText().contains("Wisconsin")) {
                            wisconsin++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Wisconsin")) {
                            wisconsin++;
                        }
                    }

                    //BADGERS
                    for (Status st : status) {
                        if (st.getText().contains("Badger")) {
                            wisconsin++;
                        }
                    }
                    for (Status st : status1) {
                        if (st.getText().contains("Badger")) {
                            wisconsin++;
                        }
                    }

                    Team team1 = new Team("Ohio State", ohiostate);
                    Team team2 = new Team("Michigan", michigan);
                    Team team3 = new Team("Penn State", pennstate);
                    Team team4 = new Team("Michigan State", michiganstate);
                    Team team5 = new Team("Maryland", maryland);
                    Team team6 = new Team("Indiana", indiana);
                    Team team7 = new Team("Rutgers", rutgers);
                    Team team8 = new Team("Northwestern", northwestern);
                    Team team9 = new Team("Wisconsin", wisconsin);
                    Team team10 = new Team("Purdue", purdue);
                    Team team11 = new Team("Iowa", iowa);
                    Team team12 = new Team("Nebraska", nebraska);
                    Team team13 = new Team("Minnesota", minnesota);
                    Team team14 = new Team("Illinois", illinois);

                    teamlist.addTeam(team1);
                    teamlist.addTeam(team2);
                    teamlist.addTeam(team3);
                    teamlist.addTeam(team4);
                    teamlist.addTeam(team5);
                    teamlist.addTeam(team6);
                    teamlist.addTeam(team7);
                    teamlist.addTeam(team8);
                    teamlist.addTeam(team9);
                    teamlist.addTeam(team10);
                    teamlist.addTeam(team11);
                    teamlist.addTeam(team12);
                    teamlist.addTeam(team13);
                    teamlist.addTeam(team14);

                    //teamlist.getTeams();
                    session.setAttribute("teamlist", teamlist);
                    url = "/index.jsp";
//url="/test.jsp";
                } catch (TwitterException ex) {
                    java.util.logging.Logger.getLogger(RefreshServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        sc.getRequestDispatcher(url)
                .forward(request, response);

    }
}
