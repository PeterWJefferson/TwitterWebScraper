package twitter;

import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.*;

import java.util.List;

public class Twitter {

    public static void main(String[] args) throws TwitterException {

        ConfigurationBuilder cf = new ConfigurationBuilder();

        cf.setDebugEnabled(true)
                .setOAuthConsumerKey("10PdSAtKh4o8aQ6YEFWTrZwfi")
                .setOAuthConsumerSecret("lw5QUX0RnA81oPjyW7QY5EtRyu5LH3bGGP51g4snSjddl3tUMO")
                .setOAuthAccessToken("1063151798712721409-mJ2qwIXo8rRR4XRWFVLHvvwl0Sw5Yl")
                .setOAuthAccessTokenSecret("m5I1wP4vRUbLgvsMFadUb585BJyu3ZX5pd9fC7FdmjHlQ");

        TwitterFactory tf = new TwitterFactory(cf.build());
        twitter4j.Twitter twitter = tf.getInstance();
        /*twitter4j.Twitter twitter =  TwitterFactory.getSingleton();
        Query query = new Query("ipl7");
        QueryResult result = twitter.search(query);
        for(Status st: status){
            System.out.println(st.getUser().getName()+"-----"+st.getText());
        }*/

        //Query query = new Query("@ESPNCFB Alabama");
        //QueryResult result = twitter.search(query);
        List<Status> status = twitter.getHomeTimeline(new Paging(1, 200));
        /*for (Status st : status) {
            System.out.println(st.getUser().getName() + "-----" + st.getText());
        }*/
        List<Status> status1 = twitter.getHomeTimeline(new Paging(2, 200));
        /*for (Status st : status1) {
            System.out.println(st.getUser().getName() + "-----" + st.getText());
        }*/
 /*
        List<Status> status3 = twitter.getHomeTimeline(new Paging(2,200));
        for (Status st : status3) {
            System.out.println(st.getUser().getName() + "-----" + st.getText());
        }
         */
        //Big 10 West
        int illinois = 0;
        int iowa = 0;
        int minnesota = 0;
        int nebraska = 0;
        int northwestern = 0;
        int purdue = 0;
        int wisconsin = 0;
        //top 25
        int alabama = 0;
        int clemson = 0;
        int notredame = 0;
        int georgia = 0;
        int oklahoma = 0;
        int ohiostate = 0;
        int michigan = 0;
        int ucf = 0;
        int florida = 0;
        int lsu = 0;
        int washington = 0;
        int pennstate = 0;
        int washingtonstate = 0;
        int texas = 0;
        int kentucky = 0;
        int westvirginia = 0;
        int utah = 0;
        int mississippistate = 0;
        int texasam = 0;
        int syracuse = 0;
        int boisestate = 0;
        int iowastate = 0;
        int missouri = 0;
        int fresnostate = 0;

        //2 FOR LOOPS PER SCHOOL + ANY TEAM NAME KEYWORDS
        //ALABAMA
        for (Status st : status) {
            if (st.getText().contains("Alabama")) {
                alabama++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Alabama")) {
                alabama++;
            }
        }
        //CRIMSON TIDE
        for (Status st : status) {
            if (st.getText().contains("Tide")) {
                alabama++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Tide")) {
                alabama++;
            }
        }
        //CLEMSON
        for (Status st : status) {
            if (st.getText().contains("Clemson")) {
                clemson++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Clemson")) {
                clemson++;
            }
        }

        //NOTRE DAME
        for (Status st : status) {
            if (st.getText().contains("Notre Dame")) {
                notredame++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Notre Dame")) {
                notredame++;
            }
        }

        //GEORGIA
        for (Status st : status) {
            if (st.getText().contains("Georgia")) {
                georgia++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Georgia")) {
                georgia++;
            }
        }
        //MINUS GEORGIA TECH
        for (Status st : status) {
            if (st.getText().contains("Georgia Tech")) {
                georgia--;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Georgia Tech")) {
                georgia--;
            }
        }

        //OKLAHOMA
        for (Status st : status) {
            if (st.getText().contains("Oklahoma")) {
                oklahoma++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Oklahoma")) {
                oklahoma++;
            }
        }
        //SOONERS
        for (Status st : status) {
            if (st.getText().contains("Sooners")) {
                oklahoma++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Sooners")) {
                oklahoma++;
            }
        }
        //MINUS OKLAHOMA STATE
        for (Status st : status) {
            if (st.getText().contains("Oklahoma State")) {
                oklahoma--;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Oklahoma State")) {
                oklahoma--;
            }
        }
        //OHIO STATE
        for (Status st : status) {
            if (st.getText().contains("Ohio State")) {
                ohiostate++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Ohio State")) {
                ohiostate++;
            }
        }
        //BUCKEYES
        for (Status st : status) {
            if (st.getText().contains("Buckeyes")) {
                ohiostate++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Buckeyes")) {
                ohiostate++;
            }
        }

        //MICHIGAN
        for (Status st : status) {
            if (st.getText().contains("Michigan")) {
                michigan++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Michigan")) {
                michigan++;
            }
        }
        //WOLVERINES
        for (Status st : status) {
            if (st.getText().contains("Wolverines")) {
                michigan++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Wolverines")) {
                michigan++;
            }
        }
        //MINUS MICHIGAN STATE
        for (Status st : status) {
            if (st.getText().contains("Michigan State")) {
                michigan--;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Michigan State")) {
                michigan--;
            }
        }

        //UCF
        for (Status st : status) {
            if (st.getText().contains("UCF")) {
                ucf++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("UCF")) {
                ucf++;
            }
        }
        //CENTRAL FLORIDA
        for (Status st : status) {
            if (st.getText().contains("Central Florida")) {
                ucf++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Central Florida")) {
                ucf++;
            }
        }

        //Florida
        for (Status st : status) {
            if (st.getText().contains("Florida")) {
                florida++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Florida")) {
                florida++;
            }
        }
        //GATORS
        for (Status st : status) {
            if (st.getText().contains("Gators")) {
                florida++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Gators")) {
                florida++;
            }
        }
        //MINUS UCF
        for (Status st : status) {
            if (st.getText().contains("Central Florida")) {
                florida--;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Central Florida")) {
                florida--;
            }
        }
        //MINUS FLORIDA STATE
        for (Status st : status) {
            if (st.getText().contains("Florida State")) {
                florida--;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Florida State")) {
                florida--;
            }
        }

        //LSU
        for (Status st : status) {
            if (st.getText().contains("LSU")) {
                lsu++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("LSU")) {
                lsu++;
            }
        }
        //WASHINGTON
        for (Status st : status) {
            if (st.getText().contains("Washington")) {
                washington++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Washington")) {
                washington++;
            }
        }

        //MINUS WASHINGTON STATE
        for (Status st : status) {
            if (st.getText().contains("Washington State")) {
                washington--;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Washington State")) {
                washington--;
            }
        }

        //PENN STATE
        for (Status st : status) {
            if (st.getText().contains("Penn State")) {
                pennstate++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Penn State")) {
                pennstate++;
            }
        }

        //WASHINGTION STATE
        for (Status st : status) {
            if (st.getText().contains("Washington State")) {
                washingtonstate++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Washington State")) {
                washingtonstate++;
            }
        }

        //TEXAS
        for (Status st : status) {
            if (st.getText().contains("Texas")) {
                texas++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Texas")) {
                texas++;
            }
        }
        //LONGHORNS
        for (Status st : status) {
            if (st.getText().contains("Longhorns")) {
                texas++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Longhorns")) {
                texas++;
            }
        }
        //MINUS TEXAS TECH
        for (Status st : status) {
            if (st.getText().contains("Texas Tech")) {
                texas--;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Texas Tech")) {
                texas--;
            }
        }
        //MINUS A&M
        for (Status st : status) {
            if (st.getText().contains("Texas A&M")) {
                texas--;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Texas A&M")) {
                texas--;
            }
        }
        //KENTUCKY
        for (Status st : status) {
            if (st.getText().contains("Kentucky")) {
                kentucky++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Kentucky")) {
                kentucky++;
            }
        }
        //WEST VIRGINIA
        for (Status st : status) {
            if (st.getText().contains("West Virginia")) {
                westvirginia++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("West Virginia")) {
                westvirginia++;
            }
        }
        //MOUNTAINEERS
        for (Status st : status) {
            if (st.getText().contains("Mountaineers")) {
                westvirginia++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Mountaineers")) {
                westvirginia++;
            }
        }
        //UTAH
        for (Status st : status) {
            if (st.getText().contains("Utah")) {
                utah++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Utah")) {
                utah++;
            }
        }
        //MINUS UTAH STATE
        for (Status st : status) {
            if (st.getText().contains("Utah State")) {
                utah--;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Utah State")) {
                utah--;
            }
        }
        //MISSISSIPPI STATE
        for (Status st : status) {
            if (st.getText().contains("Mississippi State")) {
                mississippistate++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Mississippi State")) {
                mississippistate++;
            }
        }
        //MISS STATE
        for (Status st : status) {
            if (st.getText().contains("Miss State")) {
                mississippistate++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Miss State")) {
                mississippistate++;
            }
        }
        //TEXAS A&M
        for (Status st : status) {
            if (st.getText().contains("A&M")) {
                texasam++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("A&M")) {
                texasam++;
            }
        }
        //SYRACUSE
        for (Status st : status) {
            if (st.getText().contains("Syracuse")) {
                syracuse++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Syracuse")) {
                syracuse++;
            }
        }
        //CUSE
        for (Status st : status) {
            if (st.getText().contains("Cuse")) {
                syracuse++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Cuse")) {
                syracuse++;
            }
        }
        //NORTHWESTERN
        for (Status st : status) {
            if (st.getText().contains("Northwestern")) {
                northwestern++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Northwestern")) {
                northwestern++;
            }
        }
        //BOISE STATE
        for (Status st : status) {
            if (st.getText().contains("Boise")) {
                boisestate++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Boise")) {
                boisestate++;
            }
        }
        //IOWA STATE
        for (Status st : status) {
            if (st.getText().contains("Iowa State")) {
                iowastate++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Iowa State")) {
                iowastate++;
            }
        }
        //CYCLONES
        for (Status st : status) {
            if (st.getText().contains("Cyclones")) {
                iowastate++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Cyclones")) {
                iowastate++;
            }
        }
        //MISSOURI
        for (Status st : status) {
            if (st.getText().contains("Missouri")) {
                missouri++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Missouri")) {
                missouri++;
            }
        }
        //MIZZOU
        for (Status st : status) {
            if (st.getText().contains("Mizzou")) {
                missouri++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Mizzou")) {
                missouri++;
            }
        }
        //FRESNO STATE
        for (Status st : status) {
            if (st.getText().contains("Fresno State")) {
                fresnostate++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Fresno State")) {
                fresnostate++;
            }
        }

        //ILLINOIS + ILLINI
        for (Status st : status) {
            if (st.getText().contains("Illinois")) {
                illinois++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Illinois")) {
                illinois++;
            }
        }
        //ILLINI
        for (Status st : status) {
            if (st.getText().contains("Illini")) {
                illinois++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Illini")) {
                illinois++;
            }
        }
        //IOWA  + HAWKEYES - "IOWA STATE"
        for (Status st : status) {
            if (st.getText().contains("Iowa")) {
                iowa++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Iowa")) {
                iowa++;
            }
        }
        //HAWKEYES
        for (Status st : status) {
            if (st.getText().contains("Hawkeyes")) {
                iowa++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Hawkeyes")) {
                iowa++;
            }
        }
        //IOWA STATE
        for (Status st : status) {
            if (st.getText().contains("Iowa State")) {
                iowa--;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Iowa State")) {
                iowa--;
            }
        }

        //MINNESOTA
        for (Status st : status) {
            if (st.getText().contains("Minnesota")) {
                minnesota++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Minnesota")) {
                minnesota++;
            }
        }
        //GOLDEN GOPHERS
        for (Status st : status) {
            if (st.getText().contains("Golden Gopher")) {
                minnesota++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Golden Gopher")) {
                minnesota++;
            }
        }
        //NEBRASKA + CORNHUSKERS
        for (Status st : status) {
            if (st.getText().contains("Nebraska")) {
                nebraska++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Nebraska")) {
                nebraska++;
            }
        }
        //CORNHUSKERS
        for (Status st : status) {
            if (st.getText().contains("Cornhuskers")) {
                nebraska++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Cornhuskers")) {
                nebraska++;
            }
        }

        //NORTHWESTERN
        for (Status st : status) {
            if (st.getText().contains("Northwestern")) {
                northwestern++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Northwestern")) {
                northwestern++;
            }
        }

        //PURDUE + BOILERMAKERS
        for (Status st : status) {
            if (st.getText().contains("Purdue")) {
                purdue++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Purdue")) {
                purdue++;
            }
        }

        //BOILERMAKERS
        for (Status st : status) {
            if (st.getText().contains("Boilermaker")) {
                purdue++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Boilermaker")) {
                purdue++;
            }
        }

        //WISCONSIN + BADGERS
        for (Status st : status) {
            if (st.getText().contains("Wisconsin")) {
                wisconsin++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Wisconsin")) {
                wisconsin++;
            }
        }

        //BADGERS
        for (Status st : status) {
            if (st.getText().contains("Badger")) {
                wisconsin++;
            }
        }
        for (Status st : status1) {
            if (st.getText().contains("Badger")) {
                wisconsin++;
            }
        }

        //PRINT COUNT PER SCHOOL 
        System.out.printf("Alabama %d%n", alabama);
        System.out.printf("Clemson %d%n", clemson);
        System.out.printf("Notre Dame %d%n", notredame);
        System.out.printf("Georgia %d%n", georgia);
        System.out.printf("Oklahoma %d%n", oklahoma);
        System.out.printf("Ohio State %d%n", ohiostate);
        System.out.printf("Michigan %d%n", michigan);
        System.out.printf("UCF %d%n", ucf);
        System.out.printf("Florida %d%n", florida);
        System.out.printf("LSU %d%n", lsu);
        System.out.printf("Washington %d%n", washington);
        System.out.printf("Penn State %d%n", pennstate);
        System.out.printf("Washington State %d%n", washingtonstate);
        System.out.printf("Texas %d%n", texas);
        System.out.printf("Kentucky %d%n", kentucky);
        System.out.printf("West Virginia %d%n", westvirginia);
        System.out.printf("Utah %d%n", utah);
        System.out.printf("Mississippi State %d%n", mississippistate);
        System.out.printf("Texas A&M %d%n", texasam);
        System.out.printf("Syracuse %d%n", syracuse);
        System.out.printf("Northwestern %d%n", northwestern);
        System.out.printf("Boise State %d%n", boisestate);
        System.out.printf("Iowa State %d%n", iowastate);
        System.out.printf("Missouri %d%n", missouri);
        System.out.printf("Fresno State %d%n", fresnostate);

        System.out.printf("Illinois %d%n", illinois);
        System.out.printf("Iowa %d%n", iowa);
        System.out.printf("Minnesota %d%n", minnesota);
        System.out.printf("Nebraska %d%n", nebraska);
        System.out.printf("Northwestern %d%n", northwestern);
        System.out.printf("Purdue %d%n", purdue);
        System.out.printf("Wisconsin %d%n", wisconsin);

        //System.out.println(result);
    }
}
