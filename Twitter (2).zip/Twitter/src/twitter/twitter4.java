package twitter;

import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.*;

import java.util.List;

public class twitter4 {

    public static void main(String[] args) throws TwitterException {

        ConfigurationBuilder cf = new ConfigurationBuilder();

        cf.setDebugEnabled(true)
                .setOAuthConsumerKey("10PdSAtKh4o8aQ6YEFWTrZwfi")
                .setOAuthConsumerSecret("lw5QUX0RnA81oPjyW7QY5EtRyu5LH3bGGP51g4snSjddl3tUMO")
                .setOAuthAccessToken("1063151798712721409-mJ2qwIXo8rRR4XRWFVLHvvwl0Sw5Yl")
                .setOAuthAccessTokenSecret("m5I1wP4vRUbLgvsMFadUb585BJyu3ZX5pd9fC7FdmjHlQ");

        TwitterFactory tf = new TwitterFactory(cf.build());
        twitter4j.Twitter twitter = tf.getInstance();
        /*twitter4j.Twitter twitter =  TwitterFactory.getSingleton();
        Query query = new Query("ipl7");
        QueryResult result = twitter.search(query);
        for(Status st: status){
            System.out.println(st.getUser().getName()+"-----"+st.getText());
        }*/

        //Query query = new Query("@ESPNCFB Alabama");
        //QueryResult result = twitter.search(query);
        List<Status> status = twitter.getHomeTimeline();
        /*for (Status st : status) {
            System.out.println(st.getUser().getName() + "-----" + st.getText());
        }
        List<Status> status1 = twitter.getHomeTimeline(new Paging(2,200));
        for (Status st : status1) {
            System.out.println(st.getUser().getName() + "-----" + st.getText());
        }
        List<Status> status3 = twitter.getHomeTimeline(new Paging(3,200));
        for (Status st : status3) {
            System.out.println(st.getUser().getName() + "-----" + st.getText());
        }*/
        int iowa=0;
        
        for (Status st: status) {
            if(st.getText().contains("Alabama"))
                iowa++;
            }
        
            System.out.println(iowa);
        
        //System.out.println(result);
    }
}
